# Copyright 2026 Google LLC
# Licensed under the Apache License, Version 2.0

import pytest
from pydantic import ValidationError
from app.schemas import CoordinatorOutput, SpecialistOutput, CriticOutput

def test_coordinator_validation():
    # Valid pairings
    assert CoordinatorOutput(domain="CLOSE", designated_specialist="close_specialist", routing_reason="OK", confidence_score=0.9)
    assert CoordinatorOutput(domain="BILLING", designated_specialist="billing_specialist", routing_reason="OK", confidence_score=0.85)
    assert CoordinatorOutput(domain="EXPENSE", designated_specialist="expense_specialist", routing_reason="OK", confidence_score=0.99)
    
    # Invalid specialist mapping
    with pytest.raises(ValidationError):
         CoordinatorOutput(domain="CLOSE", designated_specialist="expense_specialist", routing_reason="mismatch", confidence_score=0.9)
         
    # Invalid domain enum
    with pytest.raises(ValidationError):
         CoordinatorOutput(domain="INVALID_DOMAIN", designated_specialist="close_specialist", routing_reason="mismatch", confidence_score=0.9)


def test_specialist_validation():
    # Valid output
    valid_data = {
        "facts": [
            {
                "claim_id": "FACT-01",
                "claim": "User L1 created and approved the adjustment.",
                "claim_type": "TRANSACTION_FACT",
                "evidence_refs": [{"source_id": "TX-JE-1001", "source_type": "transaction"}]
            }
        ],
        "hypotheses": [
            {
                "hypothesis_id": "HYP-01",
                "statement": "Urgent posting caused SoD violation.",
                "basis_source_ids": ["TX-JE-1001"],
                "uncertainty": "unknown"
            }
        ],
        "missing_evidence": [],
        "confidence": "HIGH",
        "recommendation": "MANUAL_INVESTIGATION",
        "rationale": "Direct SOX control violation."
    }
    obj = SpecialistOutput(**valid_data)
    assert obj.confidence == "HIGH"
    
    # Missing evidence reference in facts
    invalid_data = valid_data.copy()
    invalid_data["facts"] = [
        {
            "claim_id": "FACT-01",
            "claim": "No citation fact",
            "claim_type": "TRANSACTION_FACT",
            "evidence_refs": []  # Requires at least 1 citation reference
        }
    ]
    with pytest.raises(ValidationError):
        SpecialistOutput(**invalid_data)


def test_critic_validation():
    valid_data = {
        "verdict": "PASS",
        "claim_checks": [
            {
                "claim_id": "FACT-01",
                "status": "SUPPORTED",
                "validated_source_ids": ["TX-JE-1001"],
                "reason": "Matches transaction parameters."
            }
        ],
        "unsupported_claims": [],
        "contradicted_claims": [],
        "missing_evidence": [],
        "invalid_source_references": [],
        "confidence_score": 0.98,
        "reasons": "Audit complete."
    }
    obj = CriticOutput(**valid_data)
    assert obj.verdict == "PASS"
