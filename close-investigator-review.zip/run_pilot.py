# Copyright 2026 Google LLC
# Licensed under the Apache License, Version 2.0

import asyncio
import json
import os
from datetime import datetime

# Import project components
from app.mock_data import get_mixed_feed, get_contract, get_policy
from app.tools import run_deterministic_rules
from app.agent import (
    coordinator_agent,
    close_specialist_agent,
    billing_specialist_agent,
    expense_specialist_agent,
    critic_agent
)
from app.audit import write_audit_packet

# ADK runner imports
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

def _parse_coordinator_json(raw_text: str) -> dict:
    """Helper to extract JSON classification from Coordinator agent output."""
    try:
        # Strip potential markdown code fences
        clean = raw_text.replace("```json", "").replace("```", "").strip()
        return json.loads(clean)
    except Exception:
        # Fallback parsing
        if "JOURNAL_ENTRY" in raw_text or "close_specialist" in raw_text:
            return {"designated_specialist": "close_specialist", "tx_type": "JOURNAL_ENTRY"}
        elif "BILLING_INVOICE" in raw_text or "billing_specialist" in raw_text:
            return {"designated_specialist": "billing_specialist", "tx_type": "BILLING_INVOICE"}
        else:
            return {"designated_specialist": "expense_specialist", "tx_type": "EXPENSE_REPORT"}

def _get_specialist_and_rag(specialist_name: str, tx: dict) -> tuple:
    """Helper to map specialist name to agent instance and RAG prompt context."""
    if specialist_name == "close_specialist":
        agent = close_specialist_agent
        rag_prompt = (
            f"1. Policies: segregation_of_duties, materiality_limits, period_cutoff, sensitive_accounts.\n"
            f"2. GL Account: {tx.get('account')}\n"
            f"3. User Profile: {tx.get('created_by')}"
        )
        return agent, rag_prompt, "Financial Close Specialist"
    elif specialist_name == "billing_specialist":
        agent = billing_specialist_agent
        rag_prompt = (
            f"1. Policies: invoice_rate_check.\n"
            f"2. Vendor: {tx.get('vendor')}\n"
            f"3. PO Number: {tx.get('po_number')}"
        )
        return agent, rag_prompt, "Vendor Billing Specialist"
    else:
        agent = expense_specialist_agent
        rag_prompt = (
            f"1. Policies: expense_meal_limits, expense_receipts.\n"
            f"2. Employee: {tx.get('employee')}\n"
            f"3. Category: {tx.get('category')}"
        )
        return agent, rag_prompt, "T&E Expense Specialist"

def _parse_critic_json(raw_text: str) -> str:
    """Clean up Critic agent response."""
    return raw_text.strip()


async def run_pipeline(tx: dict, rule_results: dict):
    """Executes the multi-agent pipeline: Coordinator -> Specialist -> Critic."""
    tx_id = tx.get("journal_id") or tx.get("invoice_id") or tx.get("report_id")
    print(f"\n[AI PIPELINE] Initiating Multi-Agent Investigation for {tx_id}...")
    
    session_service = InMemorySessionService()
    session_id = f"sess_{tx_id}_{int(datetime.now().timestamp())}"
    await session_service.create_session(app_name="app", user_id="controller", session_id=session_id)
    
    # --- Stage 1: Coordinator routing ---
    print(f" 1. [COORDINATOR] Classifying transaction payload...")
    runner = Runner(agent=coordinator_agent, app_name="app", session_service=session_service)
    
    coord_prompt = f"Determine category and routing for transaction data:\n{json.dumps(tx, indent=2)}"
    coord_out = ""
    
    async for event in runner.run_async(
        user_id="controller", session_id=session_id,
        new_message=types.Content(role="user", parts=[types.Part.from_text(text=coord_prompt)])
    ):
        if event.is_final_response():
            coord_out = event.content.parts[0].text
            
    routing = _parse_coordinator_json(coord_out)
    spec_name = routing.get("designated_specialist", "close_specialist")
    print(f"    ↳ Routed to: {spec_name} (Reason: {routing.get('reason', 'Matching schema')})")
    
    # --- Stage 2: Specialist Worker Investigation ---
    agent, rag_info, label = _get_specialist_and_rag(spec_name, tx)
    print(f" 2. [{label.upper()}] Gathering RAG evidence & drafting report...")
    
    # Reset session for Specialist execution
    await session_service.create_session(app_name="app", user_id="controller", session_id=session_id)
    session = await session_service.get_session(app_name="app", user_id="controller", session_id=session_id)
    session.state["tx_id"] = tx_id
    session.state["rule_failures"] = rule_results["failures"]
    
    runner = Runner(agent=agent, app_name="app", session_service=session_service)
    
    spec_prompt = (
        f"Perform an investigation for transaction:\n{json.dumps(tx, indent=2)}\n\n"
        f"Deterministic rule failures:\n{json.dumps(rule_results['failures'], indent=2)}\n\n"
        f"RAG Guidelines:\n{rag_info}"
    )
    
    report_out = ""
    async for event in runner.run_async(
        user_id="controller", session_id=session_id,
        new_message=types.Content(role="user", parts=[types.Part.from_text(text=spec_prompt)])
    ):
        if event.author and event.author != "controller":
            # Log RAG tool calls in real-time
            if hasattr(event, "action") and event.action and hasattr(event.action, "tool_call"):
                tc = event.action.tool_call
                print(f"       ↳ [Tool Call] {event.author} calling {tc.name}...")
            elif event.is_final_response():
                report_out = event.content.parts[0].text
                
    # --- Stage 3: Critic Verification ---
    print(f" 3. [CRITIC] Auditing specialist report for hallucinations and ungrounded claims...")
    await session_service.create_session(app_name="app", user_id="controller", session_id=session_id)
    runner = Runner(agent=critic_agent, app_name="app", session_service=session_service)
    
    critic_prompt = (
        f"Verify the following investigation report against the source transaction details and policies.\n"
        f"Source Transaction:\n{json.dumps(tx, indent=2)}\n\n"
        f"Report to Audit:\n{report_out}"
    )
    
    critic_out = ""
    async for event in runner.run_async(
        user_id="controller", session_id=session_id,
        new_message=types.Content(role="user", parts=[types.Part.from_text(text=critic_prompt)])
    ):
        if event.is_final_response():
            critic_out = event.content.parts[0].text
            
    print(f"    ↳ Audit Status: {critic_out.split('.')[0]}")
    
    return report_out, critic_out


async def main():
    print("=" * 70)
    print("  ENTERPRISE FINANCE CLOSE EXCEPTION INVESTIGATOR — PILOT RUN  ")
    print("=" * 70)
    
    feed = get_mixed_feed()
    print(f"Loaded {len(feed)} mixed financial transaction records.")
    
    print("\nRunning Stage 1: Deterministic screening & risk triage...")
    print("-" * 70)
    
    flagged_txs = []
    auto_approved = 0
    
    for tx in feed:
        tx_id = tx.get("journal_id") or tx.get("invoice_id") or tx.get("report_id")
        tx_type = tx.get("tx_type")
        results = run_deterministic_rules(tx)
        
        status = "⚠️  ESCALATE" if results["action"] == "ESCALATE_TO_HUMAN" else "✅ APPROVE"
        print(f"{tx_id:8} | Type: {tx_type:16} | Amount: ${tx['amount']:,.2f} | Score: {results['risk_score']:3} | Triage: {status}")
        
        if results["action"] == "ESCALATE_TO_HUMAN":
            flagged_txs.append((tx, results))
        else:
            auto_approved += 1
            
    print("-" * 70)
    print(f"Screening Summary: {auto_approved} Auto-Approved | {len(flagged_txs)} Flagged for Review")
    print("=" * 70)
    
    # Choose 3 representative anomalies across Close, Billing, and Expenses
    target_ids = ["JE-1001", "INV-2001", "EXP-3002"]
    
    for tx, results in flagged_txs:
        tx_id = tx.get("journal_id") or tx.get("invoice_id") or tx.get("report_id")
        if tx_id not in target_ids:
            continue
            
        print(f"\n{'#'*30} INVESTIGATING {tx_id} {'#'*30}")
        print(f"Description: {tx.get('description')}")
        print(f"Failed Control Checks:")
        for fail in results["failures"]:
            print(f"  • {fail['rule']}: {fail['error']}")
            
        # Run Multi-Agent pipeline
        ai_report, critic_report = await run_pipeline(tx, results)
        
        print("\n--- AI SPECIALIST ANALYSIS REPORT ---")
        print(ai_report)
        print("------------------------------------")
        
        # Simulate Human-in-the-loop decision
        print("\n[HITL] Simulating Human Controller sign-off...")
        human_decision = {}
        
        if tx_id == "JE-1001":
            # Close override
            human_decision = {
                "status": "APPROVED_WITH_EXCEPTION",
                "reviewer": "Emily Davis (Accounting Manager)",
                "timestamp": datetime.now().isoformat(),
                "override_reason": "Approved exception: Urgent spares replacement adjustment validated against physical dispatch logs. Approved by VP of Operations Finance.",
                "comments": "Segregation of Duties exception logged. Manual backup verified."
            }
        elif tx_id == "INV-2001":
            # Billing rejection
            human_decision = {
                "status": "REJECTED_AND_ESCALATED",
                "reviewer": "Grace Hopper (Controller)",
                "timestamp": datetime.now().isoformat(),
                "override_reason": "Rate mismatch: Vendor ConsultingCorp billed at $180/hr, exceeding the master contract limit of $150/hr. Invoice rejected.",
                "comments": "Escalated to vendor relations. Re-billing required."
            }
        elif tx_id == "EXP-3002":
            # T&E rejection
            human_decision = {
                "status": "REJECTED_AND_ESCALATED",
                "reviewer": "Henry Ford (Controllership Manager)",
                "timestamp": datetime.now().isoformat(),
                "override_reason": "Policy infraction: Employee expensed personal gaming console under Office Supplies. Missing required receipt and executive sponsor approval.",
                "comments": "Rejected. Out-of-policy expense claim returned to employee."
            }
            
        print(f"Decision: {human_decision['status']} | Reviewer: {human_decision['reviewer']}")
        
        # Write Audit Log
        packet_path = write_audit_packet(tx, results, ai_report + "\n\nCRITIC AUDIT:\n" + critic_report, human_decision)
        print(f"📜 Immutable Audit Packet saved to: {packet_path}")
        print("#" * 78)

    print("\n" + "=" * 70)
    print("FINANCE CLOSE RUN COMPLETED SUCCESSFULLY")
    print(f"Audit Packets Directory: /Users/palllavioke/agentContentGen/close-investigator/audit_packets/")
    print("=" * 70)


if __name__ == "__main__":
    asyncio.run(main())
