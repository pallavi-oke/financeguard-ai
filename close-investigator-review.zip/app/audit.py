import os
import json
import hashlib
from datetime import datetime

AUDIT_LOG_DIR = "/Users/palllavioke/agentContentGen/close-investigator/audit_packets"

def write_audit_packet(tx: dict, rule_results: dict, ai_report: str, human_decision: dict = None) -> str:
    """Consolidates and writes an immutable, tamper-evident audit packet.
    
    Includes a SHA-256 cryptographic check hash of the input, rules, AI report, 
    and human overrides for SOX-compliant data integrity.
    """
    # Ensure audit directory exists
    os.makedirs(AUDIT_LOG_DIR, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    tx_id = tx.get("journal_id") or tx.get("invoice_id") or tx.get("report_id") or "UNKNOWN"
    tx_type = tx.get("tx_type", "UNKNOWN")
    
    decision = human_decision or {
        "status": "PENDING_REVIEW",
        "reviewer": None,
        "timestamp": None,
        "override_reason": None,
        "comments": "Queued for human controller sign-off."
      }
      
    # Compute a cryptographic tamper-evident checksum for SOX logging
    raw_payload_str = json.dumps({
        "tx_id": tx_id,
        "failures": rule_results.get("failures", []),
        "ai_report": ai_report,
        "human_decision": decision
    }, sort_keys=True)
    checksum = hashlib.sha256(raw_payload_str.encode("utf-8")).hexdigest()
    
    # Structure the audit packet
    packet = {
        "metadata": {
            "system_version": "finance-control-center-v1.0",
            "model_used": "gemini-3.5-flash",
            "timestamp": datetime.now().isoformat(),
            "transaction_id": tx_id,
            "transaction_type": tx_type,
            "tamper_evident_checksum": checksum
        },
        "transaction_payload": tx,
        "deterministic_control_checks": {
            "passed": rule_results.get("passed", False),
            "risk_score": rule_results.get("risk_score", 0),
            "failures": rule_results.get("failures", []),
            "triage_decision": rule_results.get("action", "ESCALATE_TO_HUMAN")
        },
        "ai_investigation_report": ai_report,
        "human_in_the_loop_disposition": decision
    }
    
    file_path = os.path.join(AUDIT_LOG_DIR, f"audit_packet_{tx_id}_{timestamp}.json")
    
    with open(file_path, "w") as f:
        json.dump(packet, f, indent=2)
        
    return file_path
