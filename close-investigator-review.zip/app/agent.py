# ruff: noqa
# Copyright 2026 Google LLC
# Licensed under the Apache License, Version 2.0

import os
import google.auth
from dotenv import load_dotenv
from google.adk.agents import Agent
from google.adk.apps import App
from google.adk.models import Gemini
from google.genai import types

# Load local environment variables from .env if present
load_dotenv()

# Import custom tools
from .tools import (
    query_vendor_contract,
    query_related_transactions,
    read_finance_policy,
    search_historical_memos,
    get_user_profile
)

# Route authentication based on presence of GOOGLE_API_KEY
if os.environ.get("GOOGLE_API_KEY"):
    os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "False"
    print("[AUTH] GOOGLE_API_KEY found. Using Google AI Studio (API Key) authentication.")
else:
    os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"
    os.environ["GOOGLE_CLOUD_LOCATION"] = "global"
    try:
        _, project_id = google.auth.default()
        os.environ["GOOGLE_CLOUD_PROJECT"] = project_id
        print(f"[AUTH] Using Google Cloud Vertex AI (Project: {project_id}) authentication.")
    except Exception:
        if "GOOGLE_CLOUD_PROJECT" not in os.environ:
            os.environ["GOOGLE_CLOUD_PROJECT"] = "mock-gcp-project"
        print("[AUTH] Warning: No Application Default Credentials found. Attempting Vertex AI fallback.")

# Shared Model Configuration
SHARED_MODEL = Gemini(
    model="gemini-flash-latest",
    retry_options=types.HttpRetryOptions(attempts=3),
)

# --- 1. Coordinator / Router Agent ---
COORDINATOR_INSTRUCTION = """You are the Finance Exception Coordinator. 
Your role is to inspect the incoming transaction data payload, determine the transaction category, and designate the specialist agent who should handle the investigation.

Categories & Specialists:
- JOURNAL_ENTRY -> Close Specialist (Handles general ledger, cutoff, segregation of duties, timing)
- BILLING_INVOICE -> Billing Specialist (Handles vendor billing rate reconciliations, duplicate invoices, contract matching)
- EXPENSE_REPORT -> Expense Specialist (Handles employee T&E expense limit checks, travel policies, receipts)

Output your decision strictly as a JSON object:
{
  "tx_type": "[JOURNAL_ENTRY / BILLING_INVOICE / EXPENSE_REPORT]",
  "designated_specialist": "[close_specialist / billing_specialist / expense_specialist]",
  "reason": "Brief reason based on transaction payload structure."
}
"""

coordinator_agent = Agent(
    name="coordinator_agent",
    model=SHARED_MODEL,
    instruction=COORDINATOR_INSTRUCTION,
)

# --- 2. Worker Specialists ---

# A. Close Specialist
CLOSE_SPECIALIST_INSTRUCTION = """You are the Close Specialist Agent. 
Your role is to investigate general ledger adjustments (journal entries) that have failed controls.

When asked to investigate, you must:
1. Call get_user_profile to check creator/approver details.
2. Call read_finance_policy to pull relevant guidelines (segregation_of_duties, materiality_limits, period_cutoff, sensitive_accounts).
3. Call query_related_transactions and search_historical_memos to find precedents.

Synthesize your research into the following structure:
*   **Facts**: Verifiable facts from tools (no assumptions).
*   **Hypothesis**: Interpretations of why the control check failed and the risk profile.
*   **RAG Evidence**: Reference matching policies or memos.
*   **Confidence**: High, Medium, or Low.
*   **Recommendation**: Approve with Exception, Reject & Escalate, or Request Documents.
"""

close_specialist_agent = Agent(
    name="close_specialist_agent",
    model=SHARED_MODEL,
    instruction=CLOSE_SPECIALIST_INSTRUCTION,
    tools=[get_user_profile, read_finance_policy, query_related_transactions, search_historical_memos],
)

# B. Billing Specialist
BILLING_SPECIALIST_INSTRUCTION = """You are the Billing Specialist Agent. 
Your role is to investigate vendor billing invoices and identify discrepancies against master agreements.

When asked to investigate, you must:
1. Call query_vendor_contract to retrieve contracted rates and cap terms.
2. Call read_finance_policy with 'invoice_rate_check' to understand reconciliation guidelines.
3. Call query_related_transactions to check other historical bookings for this vendor.

Synthesize your research into the following structure:
*   **Facts**: Billed rate, contract rate, PO number (verifiable only).
*   **Hypothesis**: Explanation for rate discrepancy or duplicate billing pattern.
*   **RAG Evidence**: Reference contract clauses and pricing policy.
*   **Confidence**: High, Medium, or Low.
*   **Recommendation**: Approve with Exception, Reject & Escalate, or Request Documents.
"""

billing_specialist_agent = Agent(
    name="billing_specialist_agent",
    model=SHARED_MODEL,
    instruction=BILLING_SPECIALIST_INSTRUCTION,
    tools=[query_vendor_contract, read_finance_policy, query_related_transactions, search_historical_memos],
)

# C. Expense Specialist
EXPENSE_SPECIALIST_INSTRUCTION = """You are the Expense Specialist Agent. 
Your role is to investigate travel and entertainment (T&E) expense reports that exceeded policy caps or had missing receipts.

When asked to investigate, you must:
1. Call read_finance_policy to retrieve 'expense_meal_limits' or 'expense_receipts' guidelines.
2. Call get_user_profile to check employee details and roles.
3. Call query_related_transactions and search_historical_memos to see the employee's posting history.

Synthesize your research into the following structure:
*   **Facts**: Expensed amount, category, receipt status, per-diem rules.
*   **Hypothesis**: Why the policy limit was exceeded, or potential personal purchase mismatch.
*   **RAG Evidence**: Reference specific TE policy clauses.
*   **Confidence**: High, Medium, or Low.
*   **Recommendation**: Approve with Exception, Reject & Escalate, or Request Documents.
"""

expense_specialist_agent = Agent(
    name="expense_specialist_agent",
    model=SHARED_MODEL,
    instruction=EXPENSE_SPECIALIST_INSTRUCTION,
    tools=[read_finance_policy, get_user_profile, query_related_transactions, search_historical_memos],
)

# --- 3. Critic Agent ---
CRITIC_INSTRUCTION = """You are the Control Critic Agent. 
Your role is to audit the investigation report drafted by a specialist agent before it reaches the human controller.

You must verify:
1. **Ungrounded Claims**: Verify that all numbers, rates, user levels, and dates quoted in the 'Facts' section exist in the raw transaction or tool outputs. Do not let the specialist make up rates or names.
2. **Separation of Facts vs. Hypotheses**: Verify that the specialist did not blend speculation into the 'Facts' section.
3. **Professional Tone**: Ensure the tone is objective and analytical.

If the report passes, output:
[PASS] The investigation report is fully grounded and follows standard audit conventions.

If it fails (contains hallucinated rate, name, or mixes hypotheses with facts), output:
[REJECT] and list the specific ungrounded claims or formatting violations.
"""

critic_agent = Agent(
    name="critic_agent",
    model=SHARED_MODEL,
    instruction=CRITIC_INSTRUCTION,
)

# Root application
app = App(
    root_agent=coordinator_agent,
    name="app",
)
