# Copyright 2026 Google LLC
# Licensed under the Apache License, Version 2.0

import json
from datetime import datetime

# --- 1. Financial Close Journal Entries (SAP S/4HANA style) ---
MOCK_LEDGER = [
    # Normal transaction: Standard automated amortization
    {
        "tx_type": "JOURNAL_ENTRY",
        "journal_id": "JE-1000",
        "account": "180200",  # Prepaid Expenses
        "cost_center": "CC-9010",
        "entity": "US01",
        "amount": 12500.00,
        "currency": "USD",
        "posting_date": "2026-07-01T08:00:00",
        "period": "07-2026",
        "created_by": "SYS_AUTO",
        "approved_by": "SYS_AUTO",
        "description": "Amortization of prepaid software license - July 2026",
        "source_system": "SAP_SYSTEM",
        "document_id": "DOC-99210",
        "authorization_ref": "AUTO-REF-88"
    },
    # Seeded Anomaly 1: Segregation of Duties (SoD) Exception (Created & Approved by same user)
    {
        "tx_type": "JOURNAL_ENTRY",
        "journal_id": "JE-1001",
        "account": "610200",  # Spares Parts Expense
        "cost_center": "CC-4020",
        "entity": "US01",
        "amount": 125000.00,
        "currency": "USD",
        "posting_date": "2026-07-02T10:15:00",
        "period": "07-2026",
        "created_by": "ANALYST_01",
        "approved_by": "ANALYST_01",  # Same creator and approver!
        "description": "Urgent manual adjustment for warranty accrued balance",
        "source_system": "SAP_MANUAL",
        "document_id": "DOC-10294",
        "authorization_ref": "REQ-WAR-229"
    },
    # Seeded Anomaly 2: Materiality Exception (Manual entry > $250K with missing authorization ref)
    {
        "tx_type": "JOURNAL_ENTRY",
        "journal_id": "JE-1002",
        "account": "610300",  # Professional Services
        "cost_center": "CC-1100",
        "entity": "SG01",
        "amount": 320000.00,
        "currency": "USD",
        "posting_date": "2026-07-02T14:30:00",
        "period": "07-2026",
        "created_by": "ANALYST_02",
        "approved_by": "MANAGER_02",
        "description": "Manual posting for global consulting project milestones",
        "source_system": "SAP_MANUAL",
        "document_id": "DOC-10295",
        "authorization_ref": None  # Missing! Entry > $250K should have authorization_ref
    },
    # Seeded Anomaly 3: Period Cutoff Exception (Posted after period cutoff without authorization)
    {
        "tx_type": "JOURNAL_ENTRY",
        "journal_id": "JE-1003",
        "account": "620500",  # Travel and Entertainment
        "cost_center": "CC-1200",
        "entity": "US01",
        "amount": 45000.00,
        "currency": "USD",
        "posting_date": "2026-07-03T17:45:00",  # July 3rd is past the Month close cutoff (July 2nd 5:00 PM)
        "period": "06-2026",  # Trying to post to closed June period
        "created_by": "ANALYST_03",
        "approved_by": "MANAGER_03",
        "description": "Late expense report accruals reconciliation",
        "source_system": "SAP_MANUAL",
        "document_id": "DOC-10296",
        "authorization_ref": None
    },
    # Seeded Anomaly 4: Sensitive Account Check (Manual posting to Retained Earnings)
    {
        "tx_type": "JOURNAL_ENTRY",
        "journal_id": "JE-1004",
        "account": "300090",  # Retained Earnings / Sensitive Account
        "cost_center": "CC-1000",
        "entity": "US01",
        "amount": 180000.00,
        "currency": "USD",
        "posting_date": "2026-07-05T23:30:00",  # Sunday night at 11:30 PM!
        "period": "07-2026",
        "created_by": "ANALYST_04",
        "approved_by": "MANAGER_04",
        "description": "Special manual alignment adjustment to retained earnings to balance variance",
        "source_system": "SAP_MANUAL",
        "document_id": "DOC-10297",
        "authorization_ref": "ADJ-99"
    }
]

# --- 2. Billing & Invoices (Vendor Reconciliations) ---
MOCK_INVOICES = [
    # Normal Invoice
    {
        "tx_type": "BILLING_INVOICE",
        "invoice_id": "INV-2000",
        "vendor": "LogisticsInc",
        "amount": 45000.00,
        "currency": "USD",
        "po_number": "PO-9003",
        "unit_price": 450.00,
        "billed_units": 100,
        "posting_date": "2026-07-02T11:00:00",
        "description": "Freight forwarding charges for standard shipments"
    },
    # Seeded Anomaly 5: Billing rate discrepancy against contract
    {
        "tx_type": "BILLING_INVOICE",
        "invoice_id": "INV-2001",
        "vendor": "ConsultingCorp",
        "amount": 18000.00,  # 100 hours * $180 = $18k (Contract rate is $150!)
        "currency": "USD",
        "po_number": "PO-9002",
        "unit_price": 180.00,  # Discrepancy!
        "billed_units": 100,
        "posting_date": "2026-07-02T13:45:00",
        "description": "Senior PM consulting hours - Q2 milestone"
    },
    # Seeded Anomaly 6: Duplicate Invoice ID posted within short window
    {
        "tx_type": "BILLING_INVOICE",
        "invoice_id": "INV-2002",
        "vendor": "OfficeSuppliesCo",
        "amount": 1200.00,
        "currency": "USD",
        "po_number": "PO-9004",
        "unit_price": 12.00,
        "billed_units": 100,
        "posting_date": "2026-07-02T09:00:00",
        "description": "Replacement desks and office chairs"
    },
    {
        "tx_type": "BILLING_INVOICE",
        "invoice_id": "INV-2003",  # Different ID, duplicate content
        "vendor": "OfficeSuppliesCo",
        "amount": 1200.00,  # Exact duplicate amount
        "currency": "USD",
        "po_number": "PO-9004",
        "unit_price": 12.00,
        "billed_units": 100,
        "posting_date": "2026-07-02T09:30:00",  # Posted 30 mins later
        "description": "Replacement desks and office chairs"
    }
]

# --- 3. Travel & Entertainment Expenses (T&E) ---
MOCK_EXPENSES = [
    # Normal Expense
    {
        "tx_type": "EXPENSE_REPORT",
        "report_id": "EXP-3000",
        "employee": "Alice Chen",
        "category": "Travel",
        "amount": 850.00,
        "currency": "USD",
        "posting_date": "2026-07-03T10:00:00",
        "description": "Flight ticket to Singapore for manufacturing sync",
        "receipt_status": "ATTACHED"
    },
    # Seeded Anomaly 7: Meal expense exceeding policy limit ($150 per-diem)
    {
        "tx_type": "EXPENSE_REPORT",
        "report_id": "EXP-3001",
        "employee": "David Wu",
        "category": "Meals",
        "amount": 220.00,  # Exceeds $150 limit
        "currency": "USD",
        "posting_date": "2026-07-02T20:30:00",
        "description": "Business dinner with external engineering supplier representatives",
        "receipt_status": "ATTACHED"
    },
    # Seeded Anomaly 8: Missing receipt for purchase > $25 + out-of-policy item
    {
        "tx_type": "EXPENSE_REPORT",
        "report_id": "EXP-3002",
        "employee": "Bob Miller",
        "category": "Office Supplies",
        "amount": 450.00,  # > $25 and has missing receipt
        "currency": "USD",
        "posting_date": "2026-07-04T15:00:00",
        "description": "Personal gaming console for team building lounge",
        "receipt_status": "MISSING"  # Missing receipt!
    }
]

# --- 4. Unified Mixed Feed ---
# Mixed transaction feed containing a random mix of all three transaction types
# The Coordinator Agent must inspect these to delegate to the right specialist
MIXED_FEED = [
    MOCK_LEDGER[0],     # JE-1000 (Close - Normal)
    MOCK_LEDGER[1],     # JE-1001 (Close - Anomaly: SoD)
    MOCK_INVOICES[0],   # INV-2000 (Billing - Normal)
    MOCK_INVOICES[1],   # INV-2001 (Billing - Anomaly: Rate)
    MOCK_EXPENSES[0],   # EXP-3000 (Expense - Normal)
    MOCK_EXPENSES[1],   # EXP-3001 (Expense - Anomaly: Limit)
    MOCK_LEDGER[2],     # JE-1002 (Close - Anomaly: Materiality)
    MOCK_EXPENSES[2],   # EXP-3002 (Expense - Anomaly: Receipt/Policy)
    MOCK_INVOICES[2],   # INV-2002 (Billing - Normal)
    MOCK_INVOICES[3],   # INV-2003 (Billing - Anomaly: Duplicate)
    MOCK_LEDGER[3],     # JE-1003 (Close - Anomaly: Cutoff)
    MOCK_LEDGER[4]      # JE-1004 (Close - Anomaly: Retained Earnings)
]

# --- 5. Supporting Mock Databases ---

MOCK_CONTRACTS = {
    "ConsultingCorp": {
        "vendor": "ConsultingCorp",
        "contracted_rate_usd": 150.00,
        "service_cap": "Standard consulting services capped at $150.00/hour."
    },
    "LogisticsInc": {
        "vendor": "LogisticsInc",
        "contracted_rate_usd": 450.00,
        "service_cap": "Standard shipping rates fixed at $450.00 per standard freight shipment."
    },
    "OfficeSuppliesCo": {
        "vendor": "OfficeSuppliesCo",
        "contracted_rate_usd": 12.00,
        "service_cap": "Standard office supplier agreement."
    }
}

MOCK_POLICIES = {
    "segregation_of_duties": "SOX Control JE-101: Segregation of Duties. Every journal entry must be initiated by an authorized creator and reviewed/approved by a different, designated approver. System administrators or automated batch accounts are exempt only under pre-configured scheduled jobs.",
    "materiality_limits": "Corporate Finance Policy Sec 4.2: Materiality Thresholds. Any manual general ledger adjustment exceeding $250,000 USD (or equivalent) requires a documented pre-approved business justification reference (authorization_ref) in the system. Entries above $1,000,000 require CFO co-signature.",
    "period_cutoff": "Month-End Close Protocol: Cutoff Times. The ledger for any given period closes at 5:00 PM local time on the second business day of the subsequent month. Any late adjustment posted to a closed period requires explicit written approval from the Corporate Controller and must include a cutoff authorization token.",
    "sensitive_accounts": "Control Policy JE-204: Postings to Sensitive Accounts. Direct manual postings to Retained Earnings (300000-300099), Equity accounts, or Suspense/Clearing accounts (400500) are highly restricted. These require a specific business reason and are audited at 100%.",
    "invoice_rate_check": "Procurement Control BI-201: Billing Adjustments. All incoming vendor invoices must be matched against contracted master service agreements (MSAs). Any unit rate variance exceeding 0% must be flagged and routed for vendor dispute management.",
    "expense_meal_limits": "T&E Policy TE-302: Travel Expenses. The maximum allowable reimbursement for client business meals is capped at $150.00 USD per day. Items exceeding this cap must have a documented pre-authorization reference or be routed to the Finance Controller for review.",
    "expense_receipts": "T&E Policy TE-104: Receipt Verification. All expense items exceeding $25.00 USD require an attached, readable receipt image. Expenses matching restricted categories (like gaming consoles, personal leisure, electronics) are barred from reimbursement without Executive Sponsor signature."
}

MOCK_USER_ROLES = {
    "ANALYST_01": {"name": "Alice Chen", "role": "Finance Analyst", "level": "L2"},
    "ANALYST_02": {"name": "Bob Miller", "role": "Junior Accruals Analyst", "level": "L1"},
    "ANALYST_03": {"name": "Carol Smith", "role": "Senior Accountant", "level": "L3"},
    "ANALYST_04": {"name": "David Wu", "role": "FP&A Specialist", "level": "L2"},
    "MANAGER_01": {"name": "Emily Davis", "role": "Accounting Manager", "level": "L4"},
    "MANAGER_02": {"name": "Frank Jones", "role": "Finance Director", "level": "L5"},
    "MANAGER_03": {"name": "Grace Hopper", "role": "Controller", "level": "L5"},
    "MANAGER_04": {"name": "Henry Ford", "role": "Controllership Manager", "level": "L4"},
    "SYS_AUTO": {"name": "System Automated Script", "role": "Automated Process", "level": "N/A"}
}

def get_mixed_feed():
    """Retrieve the unsorted mixed transaction feed."""
    return MIXED_FEED

def get_contract(vendor: str) -> dict:
    """Retrieve contract details for a given vendor."""
    return MOCK_CONTRACTS.get(vendor, {"vendor": vendor, "contracted_rate_usd": 0.0, "service_cap": "No contracted agreement found."})

def get_policy(policy_key: str) -> str:
    """Retrieve corporate policy text."""
    return MOCK_POLICIES.get(policy_key, "Policy not found.")

def get_user_info(user_id: str) -> str:
    """Retrieve user role metadata."""
    info = MOCK_USER_ROLES.get(user_id, {"name": "Unknown User", "role": "Contractor/Other", "level": "N/A"})
    return f"Name: {info['name']}, Role: {info['role']}, Level: {info['level']}"
